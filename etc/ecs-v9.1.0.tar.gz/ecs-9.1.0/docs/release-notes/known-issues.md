---
navigation_title: "Known issues"
---

# ECS known issues [ecs-known-issues]

Known issues are significant defects or limitations that may impact your implementation.
These issues are actively being worked on and will be addressed in a future release.
Review known issues to help you make informed decisions, such as upgrading to a new version.


## 9.0.0

None at this time
