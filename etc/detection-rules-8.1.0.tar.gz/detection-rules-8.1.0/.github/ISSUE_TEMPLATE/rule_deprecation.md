---
name: Rule deprecation
about: Recommendation to deprecate a rule
title: "[Deprecation] Name of the rule"
labels: "Rule: Deprecation"
assignees: ''

---

## Link to rule


## Description

Provide a detailed description of why the rule should be deprecated
