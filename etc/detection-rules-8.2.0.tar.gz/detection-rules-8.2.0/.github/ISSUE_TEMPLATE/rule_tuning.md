---
name: Tune existing rule
about: Suggestion for logic changes to an existing rule
title: "[Rule Tuning] Name of rule"
labels: 'Rule: Tuning'
assignees: ''

---

<!-- Before submitting an issue to tune a rule, be sure to reference CONTRIBUTING.md --->

## Link to rule


## Description
<!-- Provide a detailed description of the suggested changes -->

## Example Data
<!-- If the query is to be changed, include example JSON data or a screenshot -->
